
from math import *
import useful_tools #Modules

from Student import Student
from Question import Question
from Chef import Chef
from ChineseChef import ChineseChef

print("Hello Phyton!!")
print("Ricardo Campos project 2021!!!")

print("First Project Phyton")

print("/|")
print("///")
print("|||||||")

name = "Ricardo Campos"
age = 35
value = True

print("My name\nis\' " + name + ",")

expression = "Code Academy"
print(expression + " is cool")

expression2 = "My Academy"
print(expression2.upper().isupper())

print(expression2[1])
print(expression2.index("A"))
print(expression2.replace(expression2, "new name"))
print(expression2)

print(2)
print(3*7)

print("\n\n")
my_num = -5
print(abs(my_num))
print(pow(3,2))
print(max(4,6))
print(min(2,8))
print(round(3.7))
print(floor(17.8))
print(ceil(3.8))
print(sqrt(36))

name = input("Enter your name: ")
age = input("Enter your age: ")
print("Hello " + name + "!" + "You are " + age)

num1 = input("Enter a number: ")
num2 = input("Enter another number: ")

result = float(num1) + float(num2)

print(result)

color = input("Enter a color: ")
plural_noun = input("Enter a plural noun: ")
celebrity = input ("Enter a celebrity: ")

print("Roses are " + color)
print(plural_noun + " are blue")
print("I love " + celebrity)

print("****** Lists ********")

friends = ["Kevin", "Karen", "Jim"]
print(friends)
print(friends[1])
print(friends[-1])

elements = [False, 23, "Ricardo Campos", 46, "Banner"]

print(elements[1:4])

elements[1] = "Vitoria Sport Clube"
print(elements[1])
print(elements)

print("***** Lists Functions *****")

lucky_numbers = [90, 8, 15, 16, 23, 42]
best_friends= ["Kevin", "Karen", "Jim", "Oscar", "Toby"]

print(lucky_numbers)
print(best_friends)
best_friends.extend(lucky_numbers)
print(best_friends)

best_friends.append("Creed")
print(best_friends)

best_friends.insert(1, "Kelly")
print(best_friends)

best_friends.remove("Kevin")
print((best_friends))

best_friends.pop()
print(best_friends)

print(best_friends.index("Jim"))

lucky_numbers.sort()
print(lucky_numbers)

lucky_numbers.reverse()
print(lucky_numbers)

best_friends2 = best_friends.copy()
print(best_friends2)

best_friends.clear()
print(best_friends)

print ("Tuples")

print("NOTE: Tuples can't be changed like Lists!!")
print("Tuples are used to store unchanged values")

coordinates = (4,5)

print(coordinates[1])

print("Functions!!")

def say_hi(name, age):
    print("Hello " + name + ", You are " + age)

say_hi("Ricardo", "35")
say_hi("Filipe", "34")

print("\n")
print("******** Return statement ************")

def cube(num):
    return num*num*num

result = cube(3)
print(result)

print("\n")
print("***** If statements **************")

is_male = False
is_tall = False

if is_male and is_tall:
    print("You are a male or tall or both")
elif is_male and not(is_tall):
    print("You are a short male")
else:
    print("You neither male nor tall")

def max_num (num1, num2, num3):
    if num1 >= num2 and num1 >= num3:
        result = num1
    elif num2 >= num1 and num2 >= num3:
        result = num2
    else:
        result = num3

    return result

max = max_num(24,4,8)
print(max)

print("******** Math Calculator *************")

def math_calculator():
    n1 = float(input("First Number: "))
    n2 = float(input("Second Number: "))
    option = input ("Math operation: ")

    if option == "+":
        return (n1 + n2)
    elif option == "-":
        return (n1 - n2)
    elif option == "*":
        return (n1 * n2)
    elif option == "/":
        return (n1 / n2)
    else:
        print("Wrong option!!!!!")

operation_result = math_calculator()

print(operation_result)

print("\n")
print("Dictionaries!!!!!!!!!!!!!")
print("Key/Value")

monthConversions = {
    "Jan": "January",
    "Feb": "February",
    "Mar": "March"
}

print(monthConversions["Feb"])
print(monthConversions.get("Mar"))

print("******* While Loop ************")

i = 1

while i <= 10:
    print(i)
    i += 1

print("Done with loop")

print("\n")
print("************ For loops ***************")

for letter in "Giraffe Academy":
    print(letter)

print("*** Array (basically same as List) ***")
friends = ["Jim", "Karen", "Kevin"]

for friend in friends:
    print(friend)

for index in range(10):
    print(index)

for var in range(len(friends)):
    print(friends[var])

print("\n")
print(" ****** Exponent Function **************")

def raise_to_power(base_num, pow_num):
    result = 1
    for index in range(pow_num):
        result = result * base_num

    return result

print(raise_to_power(2,3))

print("******** 2D Lists - Nested Loops ***************")

number_grid = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
    [0]
]

print(number_grid[2][1])

for row in number_grid:
    print(row)
    for col in row:
        print(col)

print("\nTranslator")

def translate(phrase):
    translation = ""
    for letter in phrase:
        if letter.lower() in "aeiou":
            if letter.isupper():
                translation = translation + "G"
            else:
                translation = translation + "g"
        else:
            translation = translation + letter
    return translation

print(translate(input("Enter a phrase: ")))

print("\n********** Comments in Python*************")

# This prints out a string
print("Python is cool!!")

#value = 10/0
#print(value)

try:
    answer = 10/0
    number = int(input("Enter a number: "))
    print(number)
except ZeroDivisionError as err:
    print(err)
except ValueError:
    print("Invalid Input!!!")

print("\n*********** Reading Files *******************")

#open("employees.txt", "r+") #read and write
#open("employees.txt", "w") #write
#open("employees.txt", "a") #append

employee_file = open("employees.txt", "r")

print(employee_file.readable())

#print("********** Text File ****************")
print(employee_file.read())

for employee in employee_file.readlines():
    print(employee)

employee_file.close()

emp_file = open("employees.txt", "a")
emp_file.write("Toby - Human Resources")
emp_file.close()

########################################
print("Modules and Pipe") # "List of Python Modules" (Google)

print(useful_tools.cars)
print(useful_tools.hello_python())

# External Libraries no workspace -> Lib (temos todos os modulos externos do Python)
# Pesquisar no google: "Python - docx", e temos modulos do python para descarregar
#Pip é usado para instalar modulos Python

# pip install python_module (linha de comandos)
#Mas no workspace tem os modulos instalados e podemos aceder fazendo:

#import docx
#docx.print (por exemplo)

#### para desinstalar um modulo do workspace fazer:

#linha de comandos: pip uninstall module_name

####################################################################

########### Classes and Objects in Python #####################

# Create an Object
student1 = Student("Jim", "Business", 3.1, False)
student2 = Student("John", "Art", 4.5, True)

print(student1.major)
print(student2.is_on_probation)

# Honor
print("**** Honor roll ****")
print(student2.on_honor_roll())

### Multiple Choice Quiz

question_prompts = [
    "What colors are apples?\n(a) Red/Green\n(b) Purple\n(c) Orange\n\n",
    "What colors are bananas?\n(a) Teal\n(b) Magenta\n(c) Yellow\n\n",
    "What colors are strawberries?\n(a) Yellow\n(b) Red\n(c) Blue\n\n"
]

questions = [
    Question(question_prompts[0], "a"),
    Question(question_prompts[1], "c"),
    Question(question_prompts[2], "b"),
]

def run_test(questions):
    score = 0
    for question in questions:
        answer = input(question.prompt)
        if answer == question.answer:
            score += 1

    print("You got " + str(score) + "/" + str(len(questions)) + " Correct")

run_test(questions)

############## Herança ############################
myChef = Chef()
myChef.make_chicken()
myChef.make_special_dish()

myChineseChef = ChineseChef()
myChineseChef.make_special_dish()















